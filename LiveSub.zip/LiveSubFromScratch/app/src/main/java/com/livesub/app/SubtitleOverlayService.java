package com.livesub.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

public class SubtitleOverlayService extends Service {
    private WindowManager windowManager;
    private TextView subtitleView;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        subtitleView = new TextView(this);
        subtitleView.setTextColor(Color.WHITE);
        subtitleView.setTextSize(18);
        subtitleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        subtitleView.setGravity(Gravity.CENTER);
        subtitleView.setPadding(24, 14, 24, 14);
        subtitleView.setBackgroundColor(0xD9000000);
        subtitleView.setText("LiveSub — اسحب لتحريك الترجمة");
        int type = android.os.Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.y = 80;
        subtitleView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                params.y = Math.max(0, (int)(params.y - event.getY() + event.getRawY()));
                try { windowManager.updateViewLayout(subtitleView, params); } catch (Exception ignored) {}
                return true;
            }
            return true;
        });
        try { windowManager.addView(subtitleView, params); } catch (Exception ignored) {}
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("subtitle") && subtitleView != null) {
            String s = intent.getStringExtra("subtitle");
            subtitleView.setText(s == null || s.trim().isEmpty() ? "LiveSub" : s);
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (subtitleView != null) {
            try { windowManager.removeView(subtitleView); } catch (Exception ignored) {}
            subtitleView = null;
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
