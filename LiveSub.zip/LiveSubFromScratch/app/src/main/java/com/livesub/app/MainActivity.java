package com.livesub.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import android.text.InputType;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 40;
    private static final String PREFS = "livesub_prefs";
    private SharedPreferences prefs;
    private TextView sourceText, translatedText, status;
    private EditText apiKey, correctionSource, correctionTarget;
    private Spinner sourceLang, targetLang;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private boolean sessionActive = false;
    private final Handler restartHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("التعرّف الصوتي غير متاح على هذا الجهاز.");
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(24));
        root.setBackgroundColor(0xFF101827);
        scroll.setFillViewport(true);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("LiveSub", 30, 0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = text("ترجمة مباشرة — نسخة أولية من الصفر", 15, 0xFFB7C5D9);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addSpace(root, 18);

        status = text("جاهز. أدخل مفتاح Gemini اختياريًا لتمكين الترجمة السحابية.", 14, 0xFF8FE3C0);
        root.addView(status);
        addSpace(root, 10);

        root.addView(text("مفتاح Gemini API (يُحفظ على هذا الجهاز)", 15, 0xFFFFFFFF));
        apiKey = new EditText(this);
        apiKey.setSingleLine(true);
        apiKey.setHint("AIza...");
        apiKey.setText(prefs.getString("api_key", ""));
        apiKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleInput(apiKey);
        root.addView(apiKey, matchWrap());
        addSpace(root, 8);

        root.addView(text("لغة الكلام", 14, 0xFFFFFFFF));
        sourceLang = spinner(new String[]{"English (US)", "French", "Arabic", "Spanish", "German", "Turkish"});
        root.addView(sourceLang, matchWrap());
        root.addView(text("لغة الترجمة", 14, 0xFFFFFFFF));
        targetLang = spinner(new String[]{"Arabic", "English", "French", "Spanish", "German", "Turkish"});
        root.addView(targetLang, matchWrap());
        addSpace(root, 10);

        Button start = button("بدء الاستماع من الميكروفون");
        start.setOnClickListener(v -> startListening());
        root.addView(start, matchWrap());
        Button stop = button("إيقاف الاستماع");
        stop.setOnClickListener(v -> stopListening());
        root.addView(stop, matchWrap());
        Button overlay = button("إظهار الترجمة العائمة فوق التطبيقات");
        overlay.setOnClickListener(v -> showOverlay());
        root.addView(overlay, matchWrap());
        Button hideOverlay = button("إخفاء الترجمة العائمة");
        hideOverlay.setOnClickListener(v -> stopService(new Intent(this, SubtitleOverlayService.class)));
        root.addView(hideOverlay, matchWrap());
        addSpace(root, 14);

        root.addView(text("النص الذي سمعه التطبيق", 16, 0xFFFFFFFF));
        sourceText = panelText();
        root.addView(sourceText, matchWrap());
        root.addView(text("الترجمة", 16, 0xFFFFFFFF));
        translatedText = panelText();
        root.addView(translatedText, matchWrap());

        addSpace(root, 16);
        root.addView(text("ذاكرة التصحيحات الشخصية", 18, 0xFFFFFFFF));
        root.addView(text("أضف مصطلحًا أو تصحيحًا موثوقًا ليُستخدم في الترجمات اللاحقة. لا يدرّب هذا نموذج Gemini تلقائيًا.", 13, 0xFFB7C5D9));
        correctionSource = new EditText(this);
        correctionSource.setHint("المصطلح أو العبارة الأصلية");
        styleInput(correctionSource);
        root.addView(correctionSource, matchWrap());
        correctionTarget = new EditText(this);
        correctionTarget.setHint("الترجمة المفضلة");
        styleInput(correctionTarget);
        root.addView(correctionTarget, matchWrap());
        Button save = button("حفظ التصحيح على الجهاز");
        save.setOnClickListener(v -> saveCorrection());
        root.addView(save, matchWrap());
        Button list = button("عرض التصحيحات المحفوظة");
        list.setOnClickListener(v -> showCorrections());
        root.addView(list, matchWrap());
        addSpace(root, 20);
        root.addView(text("تنبيه: هذه النسخة تلتقط الصوت عبر الميكروفون. التقاط الصوت الداخلي للفيديوهات يحتاج MediaProjection ويدعم فقط التطبيقات التي تسمح بذلك؛ ليس مفعّلًا بعد في هذه النسخة.", 12, 0xFFFFD18A));
    }

    private void startListening() {
        prefs.edit().putString("api_key", apiKey.getText().toString().trim()).apply();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("خدمة التعرّف على الكلام غير متوفرة.");
            return;
        }
        stopListening();
        sessionActive = true;
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { listening = true; status.setText("أستمع الآن…"); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { status.setText("أعالج الكلام…"); }
            @Override public void onError(int error) {
                listening = false;
                if (sessionActive) {
                    status.setText("أعيد تشغيل الاستماع…");
                    restartHandler.postDelayed(() -> restartRecognition(), 900);
                }
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String heard = matches.get(0);
                    sourceText.setText(heard);
                    translate(heard);
                }
                listening = false;
                if (sessionActive) restartHandler.postDelayed(() -> restartRecognition(), 450);
            }
            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) sourceText.setText(matches.get(0));
            }
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeFor((String) sourceLang.getSelectedItem()));
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
        recognitionIntent = intent;
        recognizer.startListening(intent);
    }

    private Intent recognitionIntent;

    private void restartRecognition() {
        if (!sessionActive || isFinishing()) return;
        try {
            if (recognizer != null) recognizer.startListening(recognitionIntent);
        } catch (Exception e) {
            restartHandler.postDelayed(() -> restartRecognition(), 1500);
        }
    }

    private void stopListening() {
        sessionActive = false;
        restartHandler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            try { recognizer.cancel(); recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
        listening = false;
        status.setText("تم إيقاف الاستماع.");
    }

    private void translate(String input) {
        String key = apiKey.getText().toString().trim();
        prefs.edit().putString("api_key", key).apply();
        if (key.isEmpty()) {
            String local = applyCorrections(input);
            translatedText.setText("أضف مفتاح Gemini لتفعيل الترجمة.\nالنص: " + local);
            updateOverlay(local);
            status.setText(sessionActive ? "تم التعرف على الكلام؛ أواصل الاستماع. الترجمة السحابية غير مفعلة." : "تم التعرف على الكلام؛ الترجمة السحابية غير مفعلة.");
            return;
        }
        status.setText("جارٍ طلب الترجمة…");
        executor.execute(() -> {
            try {
                String result = callGemini(key, input, (String) targetLang.getSelectedItem(), correctionsForPrompt());
                runOnUiThread(() -> {
                    translatedText.setText(result);
                    updateOverlay(result);
                    status.setText("اكتملت الترجمة.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    String fallback = applyCorrections(input);
                    translatedText.setText("تعذر الاتصال بـ Gemini.\n" + fallback + "\n" + e.getMessage());
                    updateOverlay(fallback);
                    status.setText("فشلت الترجمة السحابية؛ تحقق من الاتصال ومفتاح API.");
                });
            }
        });
    }

    private String callGemini(String key, String input, String target, String memory) throws Exception {
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + URLEncoder.encode(key, "UTF-8"));
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        String prompt = "Translate the spoken text into " + target + ". Preserve meaning, tone, names, and context. Return only the translation, no explanation. Use these user-approved glossary corrections when relevant:\n" + memory + "\nText: " + input;
        JSONObject body = new JSONObject();
        JSONArray contents = new JSONArray();
        JSONObject content = new JSONObject();
        JSONArray parts = new JSONArray();
        parts.put(new JSONObject().put("text", prompt));
        content.put("parts", parts);
        contents.put(content);
        body.put("contents", contents);
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        int code = c.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) response.append(line);
        reader.close();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + response);
        JSONObject json = new JSONObject(response.toString());
        return json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim();
    }

    private void saveCorrection() {
        String from = correctionSource.getText().toString().trim();
        String to = correctionTarget.getText().toString().trim();
        if (from.isEmpty() || to.isEmpty()) { toast("أدخل العبارة والترجمة."); return; }
        try {
            JSONArray arr = new JSONArray(prefs.getString("corrections", "[]"));
            JSONObject item = new JSONObject().put("from", from).put("to", to);
            boolean replaced = false;
            for (int i=0; i<arr.length(); i++) {
                JSONObject old = arr.getJSONObject(i);
                if (old.optString("from").equalsIgnoreCase(from)) {
                    arr.put(i, item); replaced = true; break;
                }
            }
            if (!replaced) arr.put(item);
            prefs.edit().putString("corrections", arr.toString()).apply();
            correctionSource.setText(""); correctionTarget.setText("");
            toast("تم حفظ التصحيح محليًا.");
        } catch (Exception e) { toast("تعذر حفظ التصحيح."); }
    }

    private String correctionsForPrompt() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("corrections", "[]"));
            StringBuilder out = new StringBuilder();
            for (int i=0; i<arr.length(); i++) {
                JSONObject x = arr.getJSONObject(i);
                out.append("- ").append(x.optString("from")).append(" => ").append(x.optString("to")).append("\n");
            }
            return out.toString();
        } catch (Exception e) { return ""; }
    }

    private String applyCorrections(String input) {
        try {
            JSONArray arr = new JSONArray(prefs.getString("corrections", "[]"));
            for (int i=0; i<arr.length(); i++) {
                JSONObject x = arr.getJSONObject(i);
                input = input.replace(x.optString("from"), x.optString("to"));
            }
        } catch (Exception ignored) {}
        return input;
    }

    private void showCorrections() {
        String memory = correctionsForPrompt();
        new android.app.AlertDialog.Builder(this).setTitle("التصحيحات المحفوظة")
            .setMessage(memory.isEmpty() ? "لا توجد تصحيحات بعد." : memory)
            .setPositiveButton("حسنًا", null)
            .setNegativeButton("مسح الذاكرة", (d,w) -> {
                prefs.edit().putString("corrections", "[]").apply();
                toast("تم مسح ذاكرة التصحيحات.");
            }).show();
    }

    private void showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            startActivity(i);
            toast("فعّل إذن الظهور فوق التطبيقات ثم ارجع إلى LiveSub.");
            return;
        }
        Intent i = new Intent(this, SubtitleOverlayService.class);
        i.putExtra("subtitle", translatedText == null ? "LiveSub — الترجمة ستظهر هنا" : translatedText.getText().toString());
        startService(i);
        toast("تم طلب إظهار الترجمة العائمة.");
    }

    private void updateOverlay(String value) {
        Intent i = new Intent(this, SubtitleOverlayService.class);
        i.putExtra("subtitle", value);
        try { startService(i); } catch (Exception ignored) {}
    }

    private Spinner spinner(String[] items) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        return s;
    }
    private TextView panelText() {
        TextView t = text("ستظهر النتيجة هنا…", 17, 0xFFFFFFFF);
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setBackgroundColor(0xFF253247);
        return t;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, dp(5), 0, dp(5)); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    private void styleInput(EditText e) {
        e.setTextColor(0xFFFFFFFF); e.setHintTextColor(0xFF9AA8BA);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundColor(0xFF253247);
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private void addSpace(LinearLayout l, int h) {
        View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private String localeFor(String label) {
        switch(label) {
            case "French": return "fr-FR";
            case "Arabic": return "ar";
            case "Spanish": return "es-ES";
            case "German": return "de-DE";
            case "Turkish": return "tr-TR";
            default: return "en-US";
        }
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else if (requestCode == REQ_AUDIO) status.setText("يلزم إذن الميكروفون لاستخدام التعرف الصوتي.");
    }
    @Override protected void onDestroy() {
        stopListening();
        executor.shutdownNow();
        super.onDestroy();
    }
}
